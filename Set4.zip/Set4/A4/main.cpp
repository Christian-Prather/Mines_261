/* CSCI 261 Assignment 4: calculator
 * 2/21/2019
 * Author: Christian Prather
 *
 * A program for quick calculation of unit conversions
 */
#include "calculations.h"
int main() {
// DO NOT change this main function

    menu();

    return 0;

} //1