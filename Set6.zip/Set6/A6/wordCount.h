//
// Created by christian on 4/7/19.
//

#ifndef A6_WORDCOUNT_H
#define A6_WORDCOUNT_H

#include <string>
using namespace std;
// Initialization of struct should go in header ran out of time
struct WordCount
{
    int count;
    string word;
};
#endif //A6_WORDCOUNT_H
